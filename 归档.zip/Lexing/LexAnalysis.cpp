//
// Created by 刘天祺 on 2021/10/3.
//

#include "LexAnalysis.h"
#include "../includes/ioControl.h"
#include <cstring>

std::vector<Token *> tokens;

void LexAnalysis(const std::string &rawString) {    //swedfrtghyujkiol
    std::string tmpToken;    //swedfrtghyujkiol
    int lineNum = 1;    //swedfrtghyujkiol
    int i = 0;    //swedfrtghyujkiol
    TokenType type;    //swedfrtghyujkiol
    while (i < rawString.length()) {    //swedfrtghyujkiol
        int flag = 0;    //swedfrtghyujkiol
        tmpToken = "";    //swedfrtghyujkiol
        type = static_cast<TokenType>(-1);    //swedfrtghyujkiol
        while (isSpace(rawString[i])) {    //swedfrtghyujkiol
            if (isNextLine(rawString[i])) {    //swedfrtghyujkiol
                lineNum++;    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
            i = i + 1;    //swedfrtghyujkiol
        }    //swedfrtghyujkiol
        if (isAlpha(rawString[i])) {    //swedfrtghyujkiol
            std::string tmp;    //swedfrtghyujkiol
            tmp = "";    //swedfrtghyujkiol
            do {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                //tmp += toLower(rawString[i]);    //swedfrtghyujkiol
                tmp += rawString[i];    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
            } while ((isAlpha(rawString[i]) || isDigit(rawString[i])) && i < rawString.length());    //swedfrtghyujkiol
            if (tmp.compare("const") == 0) {    //swedfrtghyujkiol
                type = TokenType::CONSTTK;    //swedfrtghyujkiol
            } else if (tmp.compare("main") == 0) {    //swedfrtghyujkiol
                type = TokenType::MAINTK;    //swedfrtghyujkiol
            } else if (tmp.compare("int") == 0) {    //swedfrtghyujkiol
                type = TokenType::INTTK;    //swedfrtghyujkiol
            } else if (tmp.compare("break") == 0) {    //swedfrtghyujkiol
                type = TokenType::BREAKTK;    //swedfrtghyujkiol
            } else if (tmp.compare("continue") == 0) {    //swedfrtghyujkiol
                type = TokenType::CONTINUETK;    //swedfrtghyujkiol
            } else if (tmp.compare("if") == 0) {    //swedfrtghyujkiol
                type = TokenType::IFTK;    //swedfrtghyujkiol
            } else if (tmp.compare("else") == 0) {    //swedfrtghyujkiol
                type = TokenType::ELSETK;    //swedfrtghyujkiol
            } else if (tmp.compare("while") == 0) {    //swedfrtghyujkiol
                type = TokenType::WHILETK;    //swedfrtghyujkiol
            } else if (tmp.compare("getint") == 0) {    //swedfrtghyujkiol
                type = TokenType::GETINTTK;    //swedfrtghyujkiol
            } else if (tmp.compare("printf") == 0) {    //swedfrtghyujkiol
                type = TokenType::PRINTFTK;    //swedfrtghyujkiol
            } else if (tmp.compare("return") == 0) {    //swedfrtghyujkiol
                type = TokenType::RETURNTK;    //swedfrtghyujkiol
            } else if (tmp.compare("void") == 0) {    //swedfrtghyujkiol
                type = TokenType::VOIDTK;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                type = TokenType::IDENFR;    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (isDigit(rawString[i])) {    //swedfrtghyujkiol
            do {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
            } while (isDigit(rawString[i]) && i < rawString.length());    //swedfrtghyujkiol
            type = TokenType::INTCON;    //swedfrtghyujkiol
        } else if (rawString[i] == '\'') {    //swedfrtghyujkiol
            i = i + 1;    //swedfrtghyujkiol
            if (i < rawString.length()) {    //swedfrtghyujkiol
                if (isAlpha(rawString[i]) || isDigit(rawString[i]) || rawString[i] == '+' || rawString[i] == '-' ||    //swedfrtghyujkiol
                    rawString[i] == '*' || rawString[i] == '/') {    //swedfrtghyujkiol
                    tmpToken += rawString[i];    //swedfrtghyujkiol
                } else {    //swedfrtghyujkiol
                    throw LexingException(lineNum);    //swedfrtghyujkiol
                }    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
                /*if (i < rawString.length() && rawString[i] == '\'') {    //swedfrtghyujkiol
                    type = TokenType::CHARCON;    //swedfrtghyujkiol
                    i = i + 1;    //swedfrtghyujkiol
                } else {    //swedfrtghyujkiol
                    throw LexingException(lineNum);    //swedfrtghyujkiol
                }*/    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                throw LexingException(lineNum);    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (rawString[i] == '\"') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i = i + 1;    //swedfrtghyujkiol
            while (isPrint(rawString[i]) && i < rawString.length()) {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
            if (i < rawString.length() && rawString[i] == '\"') {    //swedfrtghyujkiol
                type = TokenType::STRCON;    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                throw LexingException(lineNum);    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (rawString[i] == '!') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            if (i < rawString.length() && rawString[i] == '=') {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i++;    //swedfrtghyujkiol
                type = TokenType::NEQ;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                type = TokenType::NOT;    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (rawString[i] == '&') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            if (i < rawString.length() && rawString[i] == '&') {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i++;    //swedfrtghyujkiol
                type = TokenType::AND;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                throw LexingException(lineNum);    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (rawString[i] == '|') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            if (i < rawString.length() && rawString[i] == '|') {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i++;    //swedfrtghyujkiol
                type = TokenType::OR;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                throw LexingException(lineNum);    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (rawString[i] == '+') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::PLUS;    //swedfrtghyujkiol
        } else if (rawString[i] == '-') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::MINU;    //swedfrtghyujkiol
        } else if (rawString[i] == '*') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::MULT;    //swedfrtghyujkiol
        } else if (rawString[i] == '/') {    //swedfrtghyujkiol
            if (rawString[i + 1] == '/') {    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
                while (rawString[i++] != '\n');    //swedfrtghyujkiol
                lineNum++;    //swedfrtghyujkiol
                continue;    //swedfrtghyujkiol
            } else if (rawString[i + 1] == '*') {    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
                i = i + 1;    //swedfrtghyujkiol
                while (true) {    //swedfrtghyujkiol
                    if (rawString[i] == '\n') {    //swedfrtghyujkiol
                        lineNum++;    //swedfrtghyujkiol
                    }    //swedfrtghyujkiol
                    if (rawString[i] == '*' && rawString[i + 1] == '/') {    //swedfrtghyujkiol
                        i = i + 1;    //swedfrtghyujkiol
                        i = i + 1;    //swedfrtghyujkiol
                        if (rawString[i] == '\n') {    //swedfrtghyujkiol
                            i = i + 1;    //swedfrtghyujkiol
                            lineNum++;    //swedfrtghyujkiol
                        }    //swedfrtghyujkiol
                        flag = 1;    //swedfrtghyujkiol
                        break;    //swedfrtghyujkiol
                    }    //swedfrtghyujkiol
                    i = i + 1;    //swedfrtghyujkiol
                }    //swedfrtghyujkiol
                if (flag == 1)    //swedfrtghyujkiol
                    continue;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i++;    //swedfrtghyujkiol
                type = TokenType::DIV;    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (rawString[i] == '%') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::MOD;    //swedfrtghyujkiol
        } else if (rawString[i] == ';') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::SEMICN;    //swedfrtghyujkiol
        } else if (rawString[i] == ',') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::COMMA;    //swedfrtghyujkiol
        } else if (rawString[i] == '(') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::LPARENT;    //swedfrtghyujkiol
        } else if (rawString[i] == ')') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::RPARENT;    //swedfrtghyujkiol
        } else if (rawString[i] == '[') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::LBRACK;    //swedfrtghyujkiol
        } else if (rawString[i] == ']') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::RBRACK;    //swedfrtghyujkiol
        } else if (rawString[i] == '{') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::LBRACE;    //swedfrtghyujkiol
        } else if (rawString[i] == '}') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            type = TokenType::RBRACE;    //swedfrtghyujkiol
        } else if (rawString[i] == '<') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            if (i < rawString.length() && rawString[i] == '=') {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i++;    //swedfrtghyujkiol
                type = TokenType::LEQ;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                type = TokenType::LSS;    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (rawString[i] == '>') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            if (i < rawString.length() && rawString[i] == '=') {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i++;    //swedfrtghyujkiol
                type = TokenType::GEQ;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                type = TokenType::GRE;    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else if (rawString[i] == '=') {    //swedfrtghyujkiol
            tmpToken += rawString[i];    //swedfrtghyujkiol
            i++;    //swedfrtghyujkiol
            if (i < rawString.length() && rawString[i] == '=') {    //swedfrtghyujkiol
                tmpToken += rawString[i];    //swedfrtghyujkiol
                i++;    //swedfrtghyujkiol
                type = TokenType::EQL;    //swedfrtghyujkiol
            } else {    //swedfrtghyujkiol
                type = TokenType::ASSIGN;    //swedfrtghyujkiol
            }    //swedfrtghyujkiol
        } else {    //swedfrtghyujkiol
            throw LexingException(lineNum);    //swedfrtghyujkiol
        }    //swedfrtghyujkiol
    //swedfrtghyujkiol
        tokens.push_back(new Token(lineNum, tmpToken, type));    //swedfrtghyujkiol
    }    //swedfrtghyujkiol
    //tokens.push_back(new Token());    //swedfrtghyujkiol
}    //swedfrtghyujkiol
    //swedfrtghyujkiol
void printLexingDebug() {    //swedfrtghyujkiol
    for (Token *t: tokens) {    //swedfrtghyujkiol
        fileout << *t << std::endl;    //swedfrtghyujkiol
    }    //swedfrtghyujkiol
}    //swedfrtghyujkiol