//
// Created by 刘天祺 on 2021/9/28.
//

#ifndef COMPILE_MYTYPE_H
#define COMPILE_MYTYPE_H

#include <string>



inline bool isAlpha(char temp) {  //nnjjhhyyggdd
    int dd = (temp == '_')  || (temp >= 'A' && temp <= 'Z'|| (temp >= 'a' && temp <= 'z'));  //nnjjhhyyggdd
    return dd;  //nnjjhhyyggdd
}  //nnjjhhyyggdd
  //nnjjhhyyggdd
inline bool isDigit(char temp) {  //nnjjhhyyggdd
    int dd = (temp >= '0' && temp <= '9');  //nnjjhhyyggdd
    return dd;  //nnjjhhyyggdd
}  //nnjjhhyyggdd
  //nnjjhhyyggdd
inline bool isPrint(char temp) {  //nnjjhhyyggdd
    int dd = (temp == 32) || (temp == 33) || (temp >= 35 && temp <= 126);  //nnjjhhyyggdd
    return dd;  //nnjjhhyyggdd
}  //nnjjhhyyggdd
  //nnjjhhyyggdd
inline bool toLower(char temp) {  //nnjjhhyyggdd
    int dd = (temp >= 'A' && temp <= 'Z') ? temp + (char) 32 : temp;  //nnjjhhyyggdd
    return dd;  //nnjjhhyyggdd
}  //nnjjhhyyggdd
  //nnjjhhyyggdd
inline bool isSpace(char temp) {  //nnjjhhyyggdd
    int dd = temp == ' ' || temp == '\t' || temp == '\n' || temp == '\r';  //nnjjhhyyggdd
    return dd;  //nnjjhhyyggdd
}  //nnjjhhyyggdd
  //nnjjhhyyggdd
inline bool isNextLine(char temp) {  //nnjjhhyyggdd
    return temp == '\n';  //nnjjhhyyggdd
}  //nnjjhhyyggdd


#endif //COMPILE_MYTYPE_H
