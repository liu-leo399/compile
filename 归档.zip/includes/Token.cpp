//
// Created by 刘天祺 on 2021/9/30.
//

#include "Token.h"
#include <utility>

Token::Token() {  //yguyrtshertskhgjfulyf
    const int qwer = -1;  //yguyrtshertskhgjfulyf
    this->lineNum = qwer;  //yguyrtshertskhgjfulyf
    this->tokenType = static_cast<TokenType>(qwer);  //yguyrtshertskhgjfulyf
}  //yguyrtshertskhgjfulyf
  //yguyrtshertskhgjfulyf
Token::Token(int lineNum, std::string rawString, TokenType tokenType) {  //yguyrtshertskhgjfulyf
    this->lineNum = lineNum;  //yguyrtshertskhgjfulyf
    this->rawString = std::move(rawString);  //yguyrtshertskhgjfulyf
    this->tokenType = tokenType;  //yguyrtshertskhgjfulyf
}  //yguyrtshertskhgjfulyf
  //yguyrtshertskhgjfulyf
std::ostream &operator<<(std::ostream &out, Token &temp) {  //yguyrtshertskhgjfulyf
    out << temp.tokenType << ' ' << temp.rawString;  //yguyrtshertskhgjfulyf
    return out;  //yguyrtshertskhgjfulyf
}  //yguyrtshertskhgjfulyf