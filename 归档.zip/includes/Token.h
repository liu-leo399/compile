//
// Created by 刘天祺 on 2021/9/30.
//

#ifndef COMPILE_TOKEN_H
#define COMPILE_TOKEN_H

#include <string>
#include "TokenType.h"

class Token {
private:
    int lineNum;
    std::string rawString;
    TokenType tokenType;
public:
    Token();

    Token(int lineNum, std::string rawString, TokenType tokenType);

    TokenType getTokenType() {
        return this->tokenType;
    }

    friend std::ostream &operator<<(std::ostream &out, Token &temp);
};


#endif //COMPILE_TOKEN_H
