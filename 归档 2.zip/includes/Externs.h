//
// Created by 刘天祺 on 2021/10/15.
//

#ifndef COMPILE_EXTERNS_H
#define COMPILE_EXTERNS_H

#include <fstream>
#include <vector>
#include "Token.h"

extern std::ofstream fileout;
extern std::vector<Token *> tokens;

#endif //COMPILE_EXTERNS_H
