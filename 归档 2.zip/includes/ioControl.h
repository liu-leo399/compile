//
// Created by 刘天祺 on 2021/9/28.
//

#ifndef COMPILE_IOCONTROL_H
#define COMPILE_IOCONTROL_H

#include <fstream>

std::string read();

extern std::ofstream fileout;

#endif //COMPILE_IOCONTROL_H
